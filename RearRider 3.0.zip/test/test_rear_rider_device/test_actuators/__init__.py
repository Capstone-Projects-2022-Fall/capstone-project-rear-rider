from test_actuators import test_LEDStrip

def test_cases():
    return [
        *test_LEDStrip.test_cases(),
    ]