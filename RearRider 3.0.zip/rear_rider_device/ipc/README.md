# IPC

Please go over the two test files. They can both be run from the command line.

- `python ./test_parent.py`
    - Calls `python test_child.py` as a `ChildProcess`
- `python ./test_child.py`
    - Accepts command line input, or parent process input.
