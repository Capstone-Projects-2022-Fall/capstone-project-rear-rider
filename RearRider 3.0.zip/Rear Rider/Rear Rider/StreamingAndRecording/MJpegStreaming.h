//  Created by Stefano Vettor on 28/03/16.
//  Copyright © 2016 Stefano Vettor. All rights reserved.
//
// RearRider
//
// Calin Pescaru
//
// October 2022
//
// MJpeg Streaming

#ifndef MJpegStreaming_h
#define MJpegStreaming_h

#import <UIKit/UIKit.h>

//! Project version number for MjpegStreamingKit.
FOUNDATION_EXPORT double MjpegStreamingKitVersionNumber;

//! Project version string for MjpegStreamingKit.
FOUNDATION_EXPORT const unsigned char MjpegStreamingKitVersionString[];

#endif /* MJpegStreaming_h */
